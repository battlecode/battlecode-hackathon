#!/bin/sh

pip install ujson
BATTLECODE_PLAYER_KEY="$1" python testplayer.py
