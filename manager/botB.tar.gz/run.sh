#!/bin/sh

BATTLECODE_PLAYER_KEY="$1" BATTLECODE_IP="$2" python testplayer.py
