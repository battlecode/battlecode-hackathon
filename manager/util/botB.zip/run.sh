#!/bin/bash

python3 `dirname "$0"`/Battle.py

